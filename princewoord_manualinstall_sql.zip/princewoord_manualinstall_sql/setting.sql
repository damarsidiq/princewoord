-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2018 at 05:16 PM
-- Server version: 10.2.9-MariaDB-10.2.9+maria~xenial-log
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pxpedia`
--

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `type`, `app`, `name`, `value`) VALUES
(14, 'globalpage', 6, 'dbsetting', '{"dbhost":"localhost","dbuser":"root","dbpasswd":"catormouse","dbname":"princewoord"}'),
(15, 'globalpage', 6, 'footsrc', '{"jquery_jquery-191minjs":"jquery\\/jquery-1.9.1.min.js","jqueryui":"jquery\\/jquery-ui-1.10.3.custom.min.js","princewoord_princewoordminjs":"princewoord\\/princewoord.min.js"}'),
(16, 'globalpage', 6, 'headsrc', '{"princewoord_style":"princewoord\\/default\\/styles\\/style.css","princewoord_favicon":"princewoord\\/default\\/styles\\/images\\/favicon.ico"}'),
(44, 'globalpage', 6, 'keywords', 'keywords');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
