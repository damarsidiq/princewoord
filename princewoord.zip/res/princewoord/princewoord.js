$(document).ready(function(){
    forminput();
    searchwoord();
    contenttab();
    
});
var searchedwoord           = [];
var currentsearchedwoordidx = -1;


$('body').delegate('.recentitem','click',function(event){
    event.stopPropagation();
    $('#definition').html('Definition');
    gosearchwoord($(this).html());
});

$('#thelogo').on('mousedown',function(event){
    event.stopPropagation();
    
    $(this).addClass('powerswi');
    
    setTimeout(function(){
        if($('#thelogo').attr('class').indexOf('powerswi') !== -1){
            ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
        }
    },3000);
});

$('#thelogo').on('mouseup',function(event){
    event.stopPropagation();
    
    $('#thelogo').removeClass('powerswi');
});


$('#recentsearch').on('click',function(event){
    event.stopPropagation();
    
    $('#menulist').children().addClass('empty').removeClass('active');
    $('#definition').html('Recent').addClass('active').removeClass('empty');
    $('#thecontent').addClass('loading');
    $('.contentfetched').removeClass('active');
    
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'recentlist',a:'recentlist',d:{}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        $('#pw_message').removeClass('active');
        $('#pw_definition').html(msg.pagecontent).addClass('active');
        
        $('#thecontent').removeClass('loading');
    });
});

$('.woordnavelem').on('click',function(){
     if(this.id == 'nextwoord') {
        getnextwoord();
     }
     else{
        getprevwoord();
     }
});

function getnextwoord(){
    if( searchedwoord.length>=2 && currentsearchedwoordidx<(searchedwoord.length-1) && currentsearchedwoordidx !== -1){
         currentsearchedwoordidx +=1;
         displaywoord(searchedwoord[currentsearchedwoordidx].content);
         $('#search').val(searchedwoord[currentsearchedwoordidx].qwoord);
         
         if(currentsearchedwoordidx == searchedwoord.length-1)
             $('#nextwoord').removeClass('active');
         else
             $('#nextwoord').addClass('active');
             
         if(currentsearchedwoordidx === 0)
             $('#previouswoord').removeClass('active');
         else
             $('#previouswoord').addClass('active');   
    }
}

function getprevwoord(){
    if(currentsearchedwoordidx == -1){
        currentsearchedwoordidx = searchedwoord.length-2;
        displaywoord(searchedwoord[currentsearchedwoordidx].content);
        $('#search').val(searchedwoord[currentsearchedwoordidx].qwoord);
    }
    else{
        if(currentsearchedwoordidx > 0){
            currentsearchedwoordidx -= 1;
            displaywoord(searchedwoord[currentsearchedwoordidx].content);
            $('#search').val(searchedwoord[currentsearchedwoordidx].qwoord);
        }
    }
    
    if(currentsearchedwoordidx === 0)
        $('#previouswoord').removeClass('active');
    else
        $('#previouswoord').addClass('active');
        
    if(currentsearchedwoordidx == searchedwoord.length-1)
        $('#nextwoord').removeClass('active');
    else
        $('#nextwoord').addClass('active');
  
}
function contenttab(){
    $('#menulist li').on('click',function(){
        if(typeof $(this).attr('class') != 'undefined' && $(this).attr('class').indexOf('empty') !== -1)
            return;
        
        var id= this.id;
        var contentid = 'pw_'+id;
        
        $('#menulist li').removeClass('active');
        $(this).addClass('active');
        
        $('.contentfetched').removeClass('active');
        $('#'+contentid).addClass('active');
        
        
    });
}

function searchwoord(){
    $('#gosearch').on('click',function(){
        submitsearch();
    });
    $('#search').on('keyup',function(key){
        if(key.which == 13){
            submitsearch();
        }
    });
    $('body').on('keyup',function(key){
        if(key.which == 37){
            getprevwoord();
        }
        else if(key.which == 39){
            getnextwoord();
        }
    });
}

function submitsearch(){
    $('#gosearch').addClass('loading');
    var woord = $('#search').val();
    if(woord !==''){
        gosearchwoord(woord);
    }
}


function gosearchwoord(woord){
    $('#gosearch').addClass('loading');
    $('#definition').html('Definition');
    $('#thecontent').addClass('loading');
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'ajax',a:'querywoord',d:{woord:woord}}
    }).done(function(msg){
        $('#gosearch').removeClass('loading');
        $('#thecontent').removeClass('loading');
        msg = $.parseJSON(msg);
        if(msg.error || msg.response.length === 0){
            $('.contentfetched').removeClass('active');
            $('.contentfetched').html('');
            
            $('#menulist li').addClass('empty');
            
            $('#pw_message').html(msg.message);
            $('#pw_message').addClass('active');
            
            if(searchedwoord.length >= 1){
                currentsearchedwoordidx +=1;
                $('#previouswoord').addClass('active');
            }
            $('#nextwoord').removeClass('active');
        }
        else{
            $('#pw_message').removeClass('active');
            
            var searchedwoordidx                    = searchedwoord.length;
            searchedwoord[searchedwoordidx]         = [];
            searchedwoord[searchedwoordidx].content = msg.response;
            searchedwoord[searchedwoordidx].qwoord  = woord;
            
            if(searchedwoord.length > 1){
                $('#previouswoord').addClass('active');
            }
            currentsearchedwoordidx = (searchedwoord.length-1);
            
            displaywoord(msg.response);
            $('#nextwoord').removeClass('active');
        }
        $('#gosearch').removeClass('loading');
    });
}

function displaywoord(response){
    $('.contentfetched').removeClass('active');
    $('#menulist li').removeClass('empty active');
    $('#pw_message').removeClass('active');
    var definition = '<ol>';
    
    var alsosee = '<ol>';
    var emptyalsosee = true;
    
    var similar = '<ol>';
    var emptysimilar = true;
    
    var derived = '<ol>';
    var emptyderived = true;
    
    var holonym = '<ol>';
    var emptyholonym = true;
    
    var meronym = '<ol>';
    var emptymeronym = true;
    
    var attribute = '<ol>';
    var emptyattribute = true;
    
    var hypernym = '<ol>';
    var emptyhypernym = true;
    
    var hyponym = '<ol>';
    var emptyhyponym = true;
    
    $.each(response,function(woordix,woordval){
            definition += '<li><b>'+woordval.woord+'.</b> '+'('+woordval.type+') '+woordval.definition+'</li>';
            
            if(typeof(woordval.alsosee) != 'undefined'){
                var alsoseeinner = '<li><ul>';
                
                $.each(woordval.alsosee,function(alsoidx,alsoval){
                    if(typeof(alsoval.woord) !== 'undefined'){
                        alsoseeinner += '<li><b>'+alsoval.woord+'.</b> '+'('+alsoval.type+') '+alsoval.definition+'</li>';
                        emptyalsosee = false;
                    }
                });
                alsoseeinner += '</ul></li>';
                
                if(alsoseeinner != '<li><ul></ul></li>'){
                    alsosee += alsoseeinner;
                }
                else{
                    alsosee += '<li><ul>-</ul></li>';
                }
            }

            
            
            if(typeof(woordval.similar) != 'undefined'){
                var similarinner = '<li><ul>';
                $.each(woordval.similar,function(similaridx,similarval){
                    if(typeof(similarval.woord) !== 'undefined'){
                        similarinner += '<li><b>'+similarval.woord+'.</b> '+'('+similarval.type+') '+similarval.definition+'</li>';
                        emptysimilar = false;
                    }
                });    
                similarinner += '</ul></li>';
                
                if(similarinner != '<li><ul></ul></li>')
                    similar += similarinner;   
                else{
                    similar += '<li><ul>-</ul></li>';
                }
            }

                                      
                                      
            if(typeof(woordval.derived) != 'undefined'){
                var derivedinner = '<li><ul>';
                $.each(woordval.derived,function(derivedidx,derivedval){
                    if(typeof(derivedval.woord) !== 'undefined'){
                        derivedinner += '<li><b>'+derivedval.woord+'.</b> '+'('+derivedval.type+') '+derivedval.definition+'</li>';
                        emptyderived = false;
                    }
                });
                derivedinner += '</ul></li>';
                
                if(derivedinner != '<li><ul></ul></li>')
                    derived += derivedinner;
                else{
                    derived += '<li><ul>-</ul></li>';
                }
            }

                       
            var holonyminner = '<li><ul>';                
            if(typeof(woordval.holonymcomponentof) != 'undefined'){
                $.each(woordval.holonymcomponentof,function(holonymidx,holonymval){
                    if(typeof(holonymval.woord) !== 'undefined'){
                        holonyminner += '<li><b>'+holonymval.woord+'.</b>'+'('+holonymval.type+') '+holonymval.definition+'</li>';
                        emptyholonym = false;
                    }
                });
            }
            if(typeof(woordval.holonymmemberof) != 'undefined'){
                $.each(woordval.holonymmemberof,function(holonymidx,holonymval){
                    if(typeof(holonymval.woord) !== 'undefined'){
                        holonyminner += '<li><b>'+holonymval.woord+'.</b>'+'('+holonymval.type+') '+holonymval.definition+'</li>';
                        emptyholonym = false;
                    }
                });
            }
            if(typeof(woordval.holonymtobuild) != 'undefined'){
                $.each(woordval.holonymtobuild,function(holonymidx,holonymval){
                    if(typeof(holonymval.woord) !== 'undefined'){
                        holonyminner += '<li><b>'+holonymval.woord+'.</b>'+'('+holonymval.type+') '+holonymval.definition+'</li>';
                        emptyholonym = false;
                    }
                });
            }
            holonyminner += '</ul></li>';
            
            if(holonyminner != '<li><ul></ul></li>')
                holonym += holonyminner;
            else{
                holonym += '<li><ul>-</ul></li>';
            }
            
            
            var meronyminner = '<li><ul>';
            if(typeof(woordval.meronymcomponentof) != 'undefined'){
                $.each(woordval.meronymcomponentof,function(meronymidx,meronymval){
                    if(typeof(meronymval.woord) !== 'undefined'){
                        meronyminner += '<li><b>'+meronymval.woord+'.</b>'+'('+meronymval.type+') '+meronymval.definition+'</li>';
                        emptymeronym = false;
                    }
                });
            }
            if(typeof(woordval.meronymmemberof) != 'undefined'){
                $.each(woordval.meronymmemberof,function(meronymidx,meronymval){
                    if(typeof(meronymval.woord) !== 'undefined'){
                        meronyminner += '<li><b>'+meronymval.woord+'.</b>'+'('+meronymval.type+') '+meronymval.definition+'</li>';
                        emptymeronym = false;
                    }
                });
            }
            if(typeof(woordval.meronymtobuild) != 'undefined'){
                $.each(woordval.meronymtobuild,function(meronymidx,meronymval){
                    if(typeof(meronymval.woord) !== 'undefined'){
                        meronyminner += '<li><b>'+meronymval.woord+'.</b>'+'('+meronymval.type+') '+meronymval.definition+'</li>';
                        emptymeronym = false;
                    }
                });
            }
            
            if(meronyminner != '<li><ul>'){
                meronym += meronyminner;
                meronym += '</ul></li>';
            }
            else{
                meronym += '<li><ul>-</ul></li>';
            }
            
            if(typeof(woordval.attribute) != 'undefined'){
                var attributeinner = '<li><ul>';
                $.each(woordval.attribute,function(attributeidx,attributeval){
                    if(typeof(attributeval.woord) !== 'undefined'){
                        attributeinner += '<li>'+attributeval.woord+'</li>';
                        emptyattribute = false;
                    }
                });
                attributeinner += '</ul></li>';
                
                if(attributeinner != '<li><ul></ul></li>')
                    attribute += attributeinner;
                else{
                    attribute += '<li><ul>-</ul></li>';
                }
            }
            
             if(typeof(woordval.hypernym) != 'undefined'){
                var hypernyminner = '<li><ul>';
                $.each(woordval.hypernym,function(attributeidx,hypernymval){
                    if(typeof(hypernymval.woord) !== 'undefined'){
                        hypernyminner += '<li><b>'+hypernymval.woord+'.</b>'+'('+hypernymval.type+') '+hypernymval.definition+'</li>';
                        emptyhypernym = false;
                    }
                });
                hypernyminner += '</ul></li>';
                
                if(hypernyminner != '<li><ul></ul></li>')
                    hypernym += hypernyminner;
                else{
                    hypernym += '<li><ul>-</ul></li>';
                }
            }
        
            if(typeof(woordval.hyponym) != 'undefined'){
                var hyponyminner = '<li><ul>';
                $.each(woordval.hyponym,function(hyponymidx,hyponymval){
                    if(typeof(hyponymval.woord) !== 'undefined'){
                        hyponyminner += '<li>'+hyponymval.woord+'</li>';
                        emptyhyponym = false;
                    }
                });
                hyponyminner += '</ul></li>';
                
                if(hyponyminner != '<li><ul></ul></li>')
                    hyponym += hyponyminner;
                else{
                    hyponym += '<li><ul>-</ul></li>';
                }
            }
    });
    
    definition += '</ol>';
    alsosee += '</ol>';
    similar += '</ol>';
    derived += '</ol>';
    holonym += '</ol>';
    meronym += '</ol>';
    attribute += '</ol>';
    hypernym += '</ol>';
    hyponym += '</ol>';
    
    if(emptyalsosee){
        $('#alsosee').addClass('empty');
    }
    if(emptysimilar){
        $('#similar').addClass('empty');
    }
    if(emptyderived){
        $('#derived').addClass('empty');
    }
    if(emptyholonym){
        $('#holonym').addClass('empty');
    }
    if(emptymeronym){
        $('#meronym').addClass('empty');
    }
    if(emptyattribute){
        $('#attribute').addClass('empty');
    }
    if(emptyhypernym){
        $('#hypernym').addClass('empty');
    }
    if(emptyhyponym){
        $('#hyponym').addClass('empty');
    }
    
    $('#pw_definition').html(definition);
    $('#pw_definition').addClass('active');
    
    $('#definition').addClass('active');
    
    $('#pw_alsosee').html(alsosee);
    $('#pw_similar').html(similar);
    $('#pw_derived').html(derived);
    $('#pw_holonym').html(holonym);
    $('#pw_meronym').html(meronym);
    $('#pw_attribute').html(attribute);
    $('#pw_hypernym').html(hypernym);
    $('#pw_hyponym').html(hyponym);
}

function forminput(){
    $('body').delegate('input[type="text"]','click',function(){
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            
            if($(this).attr('name').indexOf('password') !== -1 ){
               $(this).prop('type','password'); 
            }
            
            if ($(this).val() === $(this).attr('name').substr(0,formarray)) {
                $(this).val('');
            }
            
            $(this).addClass('filled');
            
            $(this).on('blur',function(){
                if ($(this).val() === '') {
                    if($(this).attr('name').indexOf('password') !== -1 ){
                        $(this).prop('type','text'); 
                    }
                    $(this).val($(this).attr('name').substr(0,formarray));
                    $(this).removeClass('filled');
                }
            });
        }
    });
}