<?php

Class Home extends Controller{
    function __construct() {
        parent::__construct();
    }
    public function pageInit($data=null,$view='home'){
        include_once(Pxpedia::getConfig('resources').'Mobile-Detect-2.8.22/Mobile_Detect.php');
		
		$detect = new Mobile_Detect;
		$isMobile = $detect->isMobile();
		if($isMobile){
			$this->addheadfootsrc(false,array('mobile'=>App::getConfig('appviews').'/styles/mobile.css'));
		}
		
		return $view;
    }
}