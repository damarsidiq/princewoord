<?php

Class Ajax extends Controller{
    function __construct(){
        parent::__construct();
        $this->setPagevar('ajax',true);
    }
    
    public function querywoord($data){
        $results = $this->model('woord')->querywoord($data['woord']);
        $response['error'] = false;
        
        if($results === false){
            $response['error'] = true;
            $response['message'] = $this->model('woord')->printerrors(false);
        }
        else{
            if(empty($results))
            {
                $response['message'] = 'queried woord not found';
            }
            else{
                $this->model('recent')->save($data['woord']);
            }
            $response['response'] = $results;
        }
        $this->setPagevar('response',$response);
        return 'ajax';
    }
}

?>