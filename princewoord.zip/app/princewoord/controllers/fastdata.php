<?php

Class fastData extends Controller{
    var $relational;
    var $typefile;
    var $filetoopen;
    function __construct() {
        parent::__construct();
        $this->relational = array();
		
    }
    public function pageInit($data=null,$view='ajax'){
        foreach($this->relational as $reltionk=>$relationv){       
            $rows = $this->model('woord')->queryrelation($reltionk);
            if($rows !== false){
                foreach($rows as $rowk=>$rowval)
                {
                    $relationids = $this->model('woord')->querywoordidbyoffsets($rowval[$reltionk]);
                    
                    if(count($relationids) == 0){
                        echo $rowval[$reltionk].'===';
                        exit();
                    }
                    else{
                        $relationinid = '';
                        foreach($relationids as $relationidsk=>$relationidsval){
                            $relationinid .= $relationidsval['id'].',';
                        }
                        
                        //echo $relationinid.'---';exit();
                        
                        if($relationinid == ''){
                            echo $relationinid.'-----';
                            exit();
                        }
                        else{
                            $relationinid = substr($relationinid,0,-1);
                            $updated = $this->model('woord')->updaterelationtoid($rowval[$reltionk],$reltionk,$relationinid);
                            if(!$updated){
                                echo $this->model('woord')->querystring().'--';
                                exit();
                            }
                        }
                    }

                }
            }
            else{
                exit();
            }
        }
    
        exit();
        
        
		return $view;
    }
}