<?php

Class RecentList extends Controller{
    function __construct(){
        parent::__construct();
        $this->setPagevar('ajax',true);
    }
    
    
    public function recentlist($data){
        $list = $this->model('recent')->thelist($data);
        $this->setPagevar('list',$list);
        return 'recentlist';
    }
}

?>