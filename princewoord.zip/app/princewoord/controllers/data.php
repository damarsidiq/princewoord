<?php

Class Data extends Controller{
    var $relational;
    var $typefile;
    var $filetoopen;
    function __construct() {
        parent::__construct();
        $this->relational = array();
        $this->relational['alsosee'] = '^';
        $this->relational['antonym'] = '!';
        $this->relational['attribute'] = '=';
        $this->relational['derived'] = "\\";
        $this->relational['holonymcomponentof'] = '%p';
        $this->relational['holonymmemberof'] = '%m';
        $this->relational['holonymtobuild'] = '%s';
        $this->relational['hypernym'] = '@';
        $this->relational['hyponym'] = '~';
        $this->relational['meronymcomponentof'] = '#p';
        $this->relational['meronymmemberof'] = '#m';
        $this->relational['meronymtobuild'] = '#s';
        $this->relational['similar'] = '&';
        $this->relational['definition'] = '|';
    }
    public function pageInit($data=null,$view='ajax'){
        $files = array();
        $files[] = array('data.noun','noun');
        $files[] = array('data.verb','vrb');
        $files[] = array('data.adj','adj');
        $files[] = array('data.adv','adv');
        
        foreach($files as $fileidx=>$fileval){
            list($this->filetoopen,$this->typefile) = $fileval;
        
            $file = fopen('http://localhost/multifair/uploads/princewoord/wordnetdata/'.$this->filetoopen,'rb');
            $counter = 0;
            $dbcount = 0;
            
            $woordarr = array();
                
                
            while(false !== ( $line = (fgets($file))) ){
                $datax = explode(' ',$line);
                
                $offset = $datax[0].$fileidx;
                
                unset($datax[0]);
                unset($datax[1]);
                unset($datax[2]);
                unset($datax[3]);
                
                $woord = array();
                $alsosee = array();
                $antonym = array();
                $attribute = array();
                $derived = array();
                $holonymcomponentof = array();
                $holonymmemberof = array();
                $holonymtobuild = array();
                $hypernym = array();
                $hyponym = array();
                $meronymcomponentof = array();
                $meronymmemberof = array();
                $meronymtobuild = array();
                $similar = array();
                $definition = array();
                
                
                $readmode = 'woord';            
                foreach($datax as $datak=>$datav){
                    switch($readmode){
                        case 'extension':
                        case 'woord':
                            if(!is_numeric($datav)){
                                if(strlen($datav) == 1 || strlen($datav) ==2 ){
                                    if(in_array($datav,$this->relational)){
                                        $readmode = array_keys($this->relational,$datav)[0];
                                    }
                                    else{
                                        if(!is_numeric($datav)){
                                            if(strpos($datav,'(') !== false)
                                            {
                                                $datav = substr($datav,strpos($datav,'('));
                                            }
                                            $woord[] = $datav;   
                                        } 
                                    }
                                }
                                else{
                                    if(strpos($datav,'(') !== false)
                                    {
                                        $datav = substr($datav,strpos($datav,'('));
                                    }
                                    $woord[] = $datav;    
                                }
                            }
                            else{
                                if($datav == '0')
                                    $readmode = 'extension';
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'alsosee':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $alsosee[] = $datav;
                                $readmode = 'alsosee';
                            }
                            else{
                                if($datav == 'v'){
                                    $alsosee[count($alsosee)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $alsosee[count($alsosee)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $alsosee[count($alsosee)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $alsosee[count($alsosee)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'antonym':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $antonym[] = $datav;
                                $readmode = 'antonym';
                            } else{
                                if($datav == 'v'){
                                    $antonym[count($antonym)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $antonym[count($antonym)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $antonym[count($antonym)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $antonym[count($antonym)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'attribute':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $attribute[] = $datav;
                                $readmode = 'attribute';
                            } else{
                                if($datav == 'v'){
                                    $attribute[count($attribute)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $attribute[count($attribute)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $attribute[count($attribute)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $attribute[count($attribute)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'derived':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $derived[] = $datav;
                                $readmode = 'derived';
                            } else{
                                if($datav == 'v'){
                                    $derived[count($derived)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $derived[count($derived)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $derived[count($derived)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $derived[count($derived)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'holonymcomponentof':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $holonymcomponentof[] = $datav;
                                $readmode = 'holonymcomponentof';
                            } else{
                                if($datav == 'v'){
                                    $holonymcomponentof[count($holonymcomponentof)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $holonymcomponentof[count($holonymcomponentof)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $holonymcomponentof[count($holonymcomponentof)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $holonymcomponentof[count($holonymcomponentof)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'holonymmemberof':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $holonymmemberof[] = $datav;
                                $readmode = 'holonymmemberof';
                            } else{
                                if($datav == 'v'){
                                    $holonymmemberof[count($holonymmemberof)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $holonymmemberof[count($holonymmemberof)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $holonymmemberof[count($holonymmemberof)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $holonymmemberof[count($holonymmemberof)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'holonymtobuild':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $holonymtobuild[] = $datav;
                                $readmode = 'holonymtobuild';
                            } else{
                                if($datav == 'v'){
                                    $holonymtobuild[count($holonymtobuild)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $holonymtobuild[count($holonymtobuild)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $holonymtobuild[count($holonymtobuild)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $holonymtobuild[count($holonymtobuild)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'hypernym':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $hypernym[] = $datav;
                                $readmode = 'hypernym';
                            } else{
                                if($datav == 'v'){
                                    $hypernym[count($hypernym)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $hypernym[count($hypernym)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $hypernym[count($hypernym)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $hypernym[count($hypernym)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'hyponym':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $hyponym[] = $datav;
                                $readmode = 'hyponym';
                            } else{
                                if($datav == 'v'){
                                    $hyponym[count($hyponym)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $hyponym[count($hyponym)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $hyponym[count($hyponym)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $hyponym[count($hyponym)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'meronymcomponentof':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $meronymcomponentof[] = $datav;
                                $readmode = 'meronymcomponentof';
                            } else{
                                if($datav == 'v'){
                                    $meronymcomponentof[count($meronymcomponentof)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $meronymcomponentof[count($meronymcomponentof)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $meronymcomponentof[count($meronymcomponentof)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $meronymcomponentof[count($meronymcomponentof)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'meronymmemberof':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $meronymmemberof[] = $datav;
                                $readmode = 'meronymmemberof';
                            } else{
                                if($datav == 'v'){
                                    $meronymmemberof[count($meronymmemberof)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $meronymmemberof[count($meronymmemberof)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $meronymmemberof[count($meronymmemberof)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $meronymmemberof[count($meronymmemberof)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'meronymtobuild':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $meronymtobuild[] = $datav;
                                $readmode = 'meronymtobuild';
                            } else{
                                if($datav == 'v'){
                                    $meronymtobuild[count($meronymtobuild)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $meronymtobuild[count($meronymtobuild)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $meronymtobuild[count($meronymtobuild)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $meronymtobuild[count($meronymtobuild)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'similar':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $similar[] = $datav;
                                $readmode = 'similar';
                            } else{
                                if($datav == 'v'){
                                    $similar[count($similar)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $similar[count($similar)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $similar[count($similar)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $similar[count($similar)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'definition':
                            $definition[] = $datav;
                        break;
                        case 'default':
                        case 'unknown':
                            if(!is_numeric($datav)){
                                if(strlen($datav) == 1 || strlen($datav) ==2 ){
                                    if(in_array($datav,$this->relational)){
                                        $readmode = array_keys($this->relational,$datav)[0];
                                    }
                                    else{
                                    }
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                    }
                }
                
                
                $woordidx = count($woordarr);
                $woordarr[$woordidx]['offset'] = $offset;
                $woordarr[$woordidx]['woord'] = $woord;
                $woordarr[$woordidx]['alsosee'] = $alsosee;
                $woordarr[$woordidx]['antonym'] = $antonym;
                $woordarr[$woordidx]['attribute'] = $attribute;
                $woordarr[$woordidx]['derived'] = $derived;
                $woordarr[$woordidx]['holonymcomponentof'] = $holonymcomponentof;
                $woordarr[$woordidx]['holonymmemberof'] = $holonymmemberof;
                $woordarr[$woordidx]['holonymtobuild'] = $holonymtobuild;
                $woordarr[$woordidx]['hypernym'] = $hypernym;
                $woordarr[$woordidx]['hyponym'] = $hyponym;
                $woordarr[$woordidx]['meronymcomponentof'] = $meronymcomponentof;
                $woordarr[$woordidx]['meronymmemberof'] = $meronymmemberof;
                $woordarr[$woordidx]['meronymtobuild'] = $meronymtobuild;
                $woordarr[$woordidx]['similar'] = $similar;
                $woordarr[$woordidx]['definition'] = $definition;
                
                
                $counter++;
                if($counter%50 == 0){
                    $insq = 'insert into woords(woord,definition,type,alsosee,antonym,derived,holonymcomponentof,holonymmemberof,holonymtobuild,hypernym,hyponym,meronymcomponentof,meronymmemberof,meronymtobuild,similar,attribute,offset) values';
                    foreach($woordarr as $wk=>$wv){
                        $insq .= '("'.implode(',',$wv['woord']).'","'. $this->model('woord')->escapestr(implode(' ',$wv['definition'])) .'","'. $this->typefile .'","'. implode(',',$wv['alsosee']) .'","'. implode(',',$wv['antonym']) .'","'. implode(',',$wv['derived']) .'","'. implode(',',$wv['holonymcomponentof']) .'","'.implode(',',$wv['holonymmemberof']) .'","'. implode(',',$wv['holonymtobuild'])  .'","'. implode(',',$wv['hypernym']) .'","'. implode(',',$wv['hyponym']) .'","'. implode(',',$wv['meronymcomponentof']).'","'. implode(',',$wv['meronymmemberof']) .'","'. implode(',',$wv['meronymtobuild']) .'","'. implode(',',$wv['similar']) .'","'. implode(',',$wv['attribute']) .'","'. $wv['offset'] .'"),';
                    }
                    $insq = substr($insq,0,-1);
                    
                    $inserted = $this->model('woord')->insertdata($insq);
                    if(!$inserted){
                        echo '-------'.$insq.'---';
                        $this->model('woord')->printerrors();
                        break;
                    }
                    else{
                        $dbcount+=50;
                    }
                    $woordarr = array();
                }
            }
            
            if(!empty($woordarr)){
                $insq = 'insert into woords(woord,definition,type,alsosee,antonym,derived,holonymcomponentof,holonymmemberof,holonymtobuild,hypernym,hyponym,meronymcomponentof,meronymmemberof,meronymtobuild,similar,attribute,offset) values';
                foreach($woordarr as $wk=>$wv){
                    $insq .= '("'.implode(',',$wv['woord']).'","'. $this->model('woord')->escapestr(implode(' ',$wv['definition'])) .'","'. $this->typefile .'","'. implode(',',$wv['alsosee']) .'","'. implode(',',$wv['antonym']) .'","'. implode(',',$wv['derived']) .'","'. implode(',',$wv['holonymcomponentof']) .'","'.implode(',',$wv['holonymmemberof']) .'","'. implode(',',$wv['holonymtobuild'])  .'","'. implode(',',$wv['hypernym']) .'","'. implode(',',$wv['hyponym']) .'","'. implode(',',$wv['meronymcomponentof']).'","'. implode(',',$wv['meronymmemberof']) .'","'. implode(',',$wv['meronymtobuild']) .'","'. implode(',',$wv['similar']) .'","'. implode(',',$wv['attribute']) .'","'. $wv['offset'] .'"),';
                }
                $insq = substr($insq,0,-1);
                
                $inserted = $this->model('woord')->insertdata($insq);
                if(!$inserted){
                    $this->model('woord')->printerrors();
                    echo '-------'.$insq.'---';
                }
                else{
                    $dbcount+=count($woordarr);
                }
                $woordarr = array();
            }
            
            
            echo 'imported success to database:'.$dbcount.'<br/>';
        }
        
        
    
        exit();
        
        
		return $view;
    }
    public function patchwoord(){
        $files = array();
        $files[] = array('data.noun','noun');
        $files[] = array('data.verb','vrb');
        $files[] = array('data.adj','adj');
        $files[] = array('data.adv','adv');
        
        foreach($files as $fileidx=>$fileval){
            if($fileidx !== 2){
                continue;
            }
            list($this->filetoopen,$this->typefile) = $fileval;
        
            $file = fopen('http://localhost/multifair/uploads/princewoord/wordnetdata/'.$this->filetoopen,'rb');
            $counter = 0;
            $dbcount = 0;
            
            $woordarr = array();
                
                $panacheflag = -1;
            while(false !== ( $line = (fgets($file))) ){
                $datax = explode(' ',$line);
                
                $offset = $datax[0].$fileidx;
                
                unset($datax[0]);
                unset($datax[1]);
                unset($datax[2]);
                unset($datax[3]);
                
                $woord = array();
                $alsosee = array();
                $antonym = array();
                $attribute = array();
                $derived = array();
                $holonymcomponentof = array();
                $holonymmemberof = array();
                $holonymtobuild = array();
                $hypernym = array();
                $hyponym = array();
                $meronymcomponentof = array();
                $meronymmemberof = array();
                $meronymtobuild = array();
                $similar = array();
                $definition = array();
                $extensionwoord = array();
                
                
                
                $readmode = 'woord';            
                foreach($datax as $datak=>$datav){
                    switch($readmode){
                        case 'extensionwoord':
                            if(!is_numeric($datav)){
                                if(strlen($datav) == 1 || strlen($datav) ==2 ){
                                    if(in_array($datav,$this->relational)){
                                        $readmode = array_keys($this->relational,$datav)[0];
                                    }
                                    else{
                                        if(!is_numeric($datav)){
                                            if(strpos($datav,'(') !== false)
                                            {
                                                $datav = substr($datav,0,strpos($datav,'('));
                                                $extensionwoord[] = $datav; 
                                            }
                                        } 
                                    }
                                }
                                else{
                                    if(strpos($datav,'(') !== false)
                                    {
                                        $datav = substr($datav,0,strpos($datav,'('));
                                        $extensionwoord[] = $datav;
                                    }
                                }
                            }
                            else{
                                if(strlen($datav) == 1){
                                    if($datav !=='0'){
                                        $readmode = 'extensionwoord';
                                    }
                                    else{
                                        $readmode = 'extension';
                                    }
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'extension':
                        case 'woord':
                            if(!is_numeric($datav)){
                                if(strlen($datav) == 1 || strlen($datav) ==2 ){
                                    if(in_array($datav,$this->relational)){
                                        $readmode = array_keys($this->relational,$datav)[0];
                                    }
                                    else{
                                        if(!is_numeric($datav)){
                                            if(strpos($datav,'(') !== false)
                                            {
                                                $datav = substr($datav,0,strpos($datav,'('));
                                                $extensionwoord[] = $datav;
                                            }
                                        } 
                                    }
                                }
                                else{
                                    if(strpos($datav,'(') !== false)
                                    {
                                        $datav = substr($datav,0,strpos($datav,'('));
                                        $extensionwoord[] = $datav;
                                    }
                                }
                            }
                            else{
                                if(strlen($datav) == 1){
                                    if($datav !=='0'){
                                        $readmode = 'extensionwoord';
                                    }
                                    else{
                                        $readmode = 'extension';
                                    }
                                }
                                else{
                                    $readmode = $readmode == 'extension' ? $readmode : 'unknown';
                                }
                            }
                        break;
                        case 'alsosee':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $alsosee[] = $datav;
                                $readmode = 'alsosee';
                            }
                            else{
                                if($datav == 'v'){
                                    $alsosee[count($alsosee)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $alsosee[count($alsosee)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $alsosee[count($alsosee)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $alsosee[count($alsosee)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'antonym':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $antonym[] = $datav;
                                $readmode = 'antonym';
                            } else{
                                if($datav == 'v'){
                                    $antonym[count($antonym)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $antonym[count($antonym)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $antonym[count($antonym)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $antonym[count($antonym)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'attribute':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $attribute[] = $datav;
                                $readmode = 'attribute';
                            } else{
                                if($datav == 'v'){
                                    $attribute[count($attribute)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $attribute[count($attribute)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $attribute[count($attribute)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $attribute[count($attribute)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'derived':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $derived[] = $datav;
                                $readmode = 'derived';
                            } else{
                                if($datav == 'v'){
                                    $derived[count($derived)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $derived[count($derived)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $derived[count($derived)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $derived[count($derived)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'holonymcomponentof':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $holonymcomponentof[] = $datav;
                                $readmode = 'holonymcomponentof';
                            } else{
                                if($datav == 'v'){
                                    $holonymcomponentof[count($holonymcomponentof)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $holonymcomponentof[count($holonymcomponentof)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $holonymcomponentof[count($holonymcomponentof)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $holonymcomponentof[count($holonymcomponentof)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'holonymmemberof':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $holonymmemberof[] = $datav;
                                $readmode = 'holonymmemberof';
                            } else{
                                if($datav == 'v'){
                                    $holonymmemberof[count($holonymmemberof)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $holonymmemberof[count($holonymmemberof)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $holonymmemberof[count($holonymmemberof)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $holonymmemberof[count($holonymmemberof)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'holonymtobuild':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $holonymtobuild[] = $datav;
                                $readmode = 'holonymtobuild';
                            } else{
                                if($datav == 'v'){
                                    $holonymtobuild[count($holonymtobuild)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $holonymtobuild[count($holonymtobuild)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $holonymtobuild[count($holonymtobuild)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $holonymtobuild[count($holonymtobuild)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'hypernym':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $hypernym[] = $datav;
                                $readmode = 'hypernym';
                            } else{
                                if($datav == 'v'){
                                    $hypernym[count($hypernym)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $hypernym[count($hypernym)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $hypernym[count($hypernym)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $hypernym[count($hypernym)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'hyponym':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $hyponym[] = $datav;
                                $readmode = 'hyponym';
                            } else{
                                if($datav == 'v'){
                                    $hyponym[count($hyponym)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $hyponym[count($hyponym)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $hyponym[count($hyponym)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $hyponym[count($hyponym)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'meronymcomponentof':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $meronymcomponentof[] = $datav;
                                $readmode = 'meronymcomponentof';
                            } else{
                                if($datav == 'v'){
                                    $meronymcomponentof[count($meronymcomponentof)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $meronymcomponentof[count($meronymcomponentof)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $meronymcomponentof[count($meronymcomponentof)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $meronymcomponentof[count($meronymcomponentof)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'meronymmemberof':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $meronymmemberof[] = $datav;
                                $readmode = 'meronymmemberof';
                            } else{
                                if($datav == 'v'){
                                    $meronymmemberof[count($meronymmemberof)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $meronymmemberof[count($meronymmemberof)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $meronymmemberof[count($meronymmemberof)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $meronymmemberof[count($meronymmemberof)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'meronymtobuild':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $meronymtobuild[] = $datav;
                                $readmode = 'meronymtobuild';
                            } else{
                                if($datav == 'v'){
                                    $meronymtobuild[count($meronymtobuild)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $meronymtobuild[count($meronymtobuild)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $meronymtobuild[count($meronymtobuild)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $meronymtobuild[count($meronymtobuild)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'similar':
                            if(is_numeric($datav) && (int)$datav !== 0){
                                $similar[] = $datav;
                                $readmode = 'similar';
                            } else{
                                if($datav == 'v'){
                                    $similar[count($similar)-1] .= '1';$readmode = 'unknown';
                                }
                                elseif($datav == 'r'){
                                    $similar[count($similar)-1] .= '3';$readmode = 'unknown';
                                }
                                elseif($datav == 'a'){
                                    $similar[count($similar)-1] .= '2';$readmode = 'unknown';
                                }
                                elseif($datav == 'n'){
                                    $similar[count($similar)-1] .= '0';$readmode = 'unknown';
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                        case 'definition':
                            $definition[] = $datav;
                        break;
                        case 'default':
                        case 'unknown':
                            if(!is_numeric($datav)){
                                if(strlen($datav) == 1 || strlen($datav) ==2 ){
                                    if(in_array($datav,$this->relational)){
                                        $readmode = array_keys($this->relational,$datav)[0];
                                    }
                                    else{
                                    }
                                }
                                else{
                                    $readmode = 'unknown';
                                }
                            }
                        break;
                    }
                }
                
                if(count($extensionwoord)){                  
                    $updated = $this->model('woord')->updateextension($offset,$extensionwoord);
                    if($updated == false){
                        //echo print_r($extensionwoord,true).'------'. $offset .'<br/><br/><br/>';
                    }
                    else{
                        $this->model('woord')->saveextension($offset);
                        $dbcount++;
                    }
                }
            }
            
            echo 'imported success to database:'.$dbcount.'<br/>';
        }
        
        
    
        exit();
        
        
		return $view;
    }
    public function applytemp(){
        $counter = $this->model('woord')->applytemp();
        echo $counter.' updated';
        return 'ajax';
    }
    public function tidychar(){
        $this->model('woord')->tidychar();
        return 'ajax';
    }
    public function backendcomma(){
        $countupdated = $this->model('woord')->backendcomma();
        echo $countupdated.' updated';
        return 'ajax';
    }
}