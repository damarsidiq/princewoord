<?php 
Class Syncapp extends Controller{
    var $config;
	function __construct(){
		parent::__construct();
		$this->setPagevar('ajax',true);
		$this->syncconfig();
	}
	public function syncconfig($data=false){
	    $this->config['sync'] = array('app','view','res','plugin','appconfig','appdb');
	}
	public function getconfig(){
	    $this->setPagevar('response',$this->config['sync']);
	    return 'ajax';
	}
	
}
