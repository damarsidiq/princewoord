<?php

Class Woord extends Model{
    function __construct(){
        parent::__construct('woords');
    }
    public function backendcomma(){
        $count = 0;
        $bec = $this->query('select * from woords where woord like "%,"');
        foreach($this->fetchQueryResult($bec) as $woordk=>$woord){
            $newwoord = substr($woord['woord'],0,-1);
            $updated = $this->query('update woords set woord = "'. $newwoord .'" where id ='.$woord['id']);
            if($updated){
                $count++;
            }
        }
        return $count;
    }
    public function applytemp(){
        $limit = array(0,100);
        $lastround = false;
        $countdbupdate = 0;
        
        while(!$lastround){
            $tabletemp = $this->query('select backupoffset from temp limit '. $limit[0] .','. $limit[1]);
            $result = $this->fetchQueryResult($tabletemp);
            if(count($result) < 100)
                $lastround = true;
                
            $offsets = '';
            foreach($result as $rk=>$rv){
                $offsets .= $rv['backupoffset'].',';
            }
            $offsets = substr($offsets,0,-1);
            
            $temps = $this->query('select id,woord from woordsbackup where offset in('. $offsets .')');
            if(!$temps){
                $this->printerrors();
                exit();
            }
            foreach($this->fetchQueryResult($temps) as $tempk=>$temp){
                $extendedwoord = $temp['woord'];
                $updateisover = $this->query('update woords set woord = "'. $extendedwoord .'" where id = '.$temp['id']);
                
                if($updateisover)
                    $countdbupdate++;
            }
            
            $limit[0] += 100;
        }

        return $countdbupdate;
    }
    public function saveextension($offset){
        return $this->query('insert into temp(backupoffset) values("'. $offset .'")');
        
    }
    public function updateextension($offset,$extensions){
        $updated = false;
        $needupdates = $this->query('select * from  woords where id = (select id from woordsbackup where offset = "'. $offset .'")');
        if($needupdates){
            $theupdate = $this->fetchQueryResult($needupdates)[0];
            $newwoordentry = $theupdate['woord'];
            $theupdatex = explode(',',$theupdate['woord']);
            foreach($extensions as $extensionwoordk=>$extensionwoord){
                if(!in_array($extensionwoord,$theupdatex)){
                    $newwoordentry .=  ','.$extensionwoord;
                }
            }
            
            if($newwoordentry !== $theupdate['woord']){
                $newwoordentry = str_replace(array('(a),','(p),',',,','(ip),'),array('','',',',''),$newwoordentry);
                $updated = $this->query('update woordsbackup set woord = "'. $newwoordentry .'" where offset = "'. $offset .'"');
                if(!$updated){
                    echo $updated.'----'. $newwoordentry .'--'. $offset.'--'.print_r($extensionwoord,true) .'"<br/>';
                    return $updated;
                }
            }
        }
        return $updated;
    }
    public function insertdata($query){
        $insert = $this->query($query);
        return $insert;
    }
    public function queryrelation($relname){
        $rows = $this->query('select distinct '.$relname.' from '.$this->table.' where '.$relname.' != ""');
        return $rows;
    }
    public function querywoordidbyoffsets($offsets){
        $offsetsx = explode(',',$offsets);
        
        $rows = $this->getrecords(array('offset'=>array('in',$offsetsx)),'id');
        return $rows;
    }
    public function updaterelationtoid($distinctoffset,$relname,$relationinid){
        return $this->updaterecord(array($relname =>$relationinid),array($relname=>$distinctoffset));
    }
    public function querywoord($qwoord){
        $qwoord     = strtolower(str_replace(' ','_',trim($qwoord)));
        $related    = array();
        $thewoords  = array();
        
        $woords = $this->getrecords(array('woord'=>array('like','%'.$qwoord.'%')));
        foreach($woords as $wk=>$woord){
            $theqwoord = false;
            if(strpos($woord['woord'],',') !== false){
                $woordx = explode(',',$woord['woord']);
                foreach($woordx as $candidatek=>$candidate){
                    if(strtolower(trim($candidate)) == $qwoord){
                        $theqwoord = true;
                        break;
                    }
                }
            }
            else{
                if(strtolower(trim($woord['woord'])) == $qwoord){
                    $theqwoord = true;
                }
            }
            
            if($theqwoord == false){
                continue;
            }
            
            $related['meronymcomponentof']  = array();
            $related['meronymmemberof']     = array();
            $related['meronymtobuild']      = array();
            $related['holonymcomponentof']  = array();
            $related['holonymmemberof']     = array();
            $related['holonymtobuild']      = array();
            $related['similar']             = array();
            $related['attribute']           = array();
            $related['alsosee']             = array();
            
            $related['meronymcomponentof']  = explode(',',$woord['meronymcomponentof']);
            $related['meronymmemberof']     = explode(',',$woord['meronymmemberof']);
            $related['meronymtobuild']      = explode(',',$woord['meronymtobuild']);
            
            $related['holonymcomponentof']  = explode(',',$woord['holonymcomponentof']);
            $related['holonymmemberof']     = explode(',',$woord['holonymmemberof']);
            $related['holonymtobuild']      = explode(',',$woord['holonymtobuild']);
            
            $related['attribute']   = explode(',',$woord['attribute']);
            $related['hypernym']    = explode(',',$woord['hypernym']);
            $related['hyponym']     = explode(',',$woord['hyponym']);
            
            $related['similar']     = explode(',',$woord['similar']);            
            $related['alsosee']     = explode(',',$woord['alsosee']);
            $related['antonym']     = explode(',',$woord['antonym']);
            $related['derived']     = explode(',',$woord['derived']);
            
            $definitionrequired = array('similar','alsosee','antonym','derived','holonymcomponentof','holonymmemberof','holonymtobuild','meronymcomponentof','meronymmemberof','meronymtobuild','hypernym');
            
            
            $offsets = array();
            $offsetstwo = array();
            foreach($related as $rk=>$rv)
            {
                if(!empty($rv)){
                    if(!in_array($rk,$definitionrequired)){
                        foreach($rv as $idx=>$val){
                            if($val !== '')
                            if(!in_array($val,$offsets))
                                $offsets[] = $val;   
                        }
                    }
                    else{
                        foreach($rv as $idx=>$val){
                            if($val !== '')
                            if(!in_array($val,$offsetstwo))
                                $offsetstwo[] = $val;   
                        }
                    }   
                }
            }
            
            if(!empty($offsets)){
                $qrelatedwoords = 'select woord,id from woords where id in ('.implode(',',$offsets).')';
                $relatedwoords = $this->query($qrelatedwoords);
                
                $relatedwoords = $this->fetchQueryResult($relatedwoords);
                
                if(!empty($relatedwoords))
                foreach($related as $rk=>$rv)
                {
                    if(in_array($rk,$definitionrequired)){
                        continue;
                    }
                    
                    foreach($rv as $idx=>$value){
                        foreach($relatedwoords as $woordk=>$woordval)
                        {
                            if($woordval['id'] == $value){
                                $woordval['woord'] = str_replace('_',' ',$woordval['woord']);
                                $related[$rk][$idx] = $woordval;
                            }
                        }
                    }
                }
            }
            
            if(!empty($offsetstwo)){
                $qsecondarywoords = 'select woord,definition,id,type from woords where id in ('.implode(',',$offsetstwo).')';
                $secondarywoords = $this->query($qsecondarywoords);
                
                if(!$secondarywoords){
                    $this->printerrors();
                    echo $this->querystring();
                }
                else{
                    $secondarywoords = $this->fetchQueryResult($secondarywoords);
                    if(!empty($secondarywoords))
                    foreach($related as $rk=>$rv)
                    {
                        if(!(in_array($rk,$definitionrequired))){
                            continue;
                        }
                        
                        foreach($rv as $idx=>$value){
                            foreach($secondarywoords as $woordk=>$woordval)
                            {
                                if($woordval['id'] == $value){
                                    $woordval['woord'] = str_replace('_',' ',$woordval['woord']);
                                    $related[$rk][$idx] = $woordval;
                                }
                            }
                        }
                    }   
                }
            }
            
            $thewoordsidx = count($thewoords);
            
            $thewoords[$thewoordsidx] = $related;
            $thewoords[$thewoordsidx]['woord'] = str_replace('_',' ',$woord['woord']);
            $thewoords[$thewoordsidx]['definition'] = $woord['definition'];
            $thewoords[$thewoordsidx]['type'] = $woord['type'];
            
        }
        return $thewoords;
    }
    
    public function tidychar(){
        $qwoord = 'b';
        $qwoord     = strtolower(str_replace(' ','_',trim($qwoord)));
        $related    = array();
        $thewoords  = array();
        
        $woords = $this->getrecords(array('woord'=>array('like',$qwoord)));
        $countupdated = 0;
        $numberindex=1;
        foreach($woords as $wk=>$woord){
            $updated = false;
            $theqwoord = false;
            if(strpos($woord['woord'],',') !== false){
                $woordx = explode(',',$woord['woord']);
                foreach($woordx as $candidatek=>$candidate){
                    if(strtolower(trim($candidate)) == $qwoord){
                        $theqwoord = true;
                        break;
                    }
                }
            }
            else{
                if(strtolower(trim($woord['woord'])) == $qwoord){
                    $theqwoord = true;
                }
            }
            
            if($theqwoord == false || in_array($woord['id'],array(36843))){
                    
                continue;
            }
            
            $cleanwoord = str_replace(array(',@i',',;c',',+',',~i',',;r',',-c',',b,'),array('','','','','','',','),$woord['woord']);
            $cleanwoord = $this->cleanjustend($cleanwoord,',b');
            
            echo $numberindex.'.'.'**'.$woord['id'].'--'.$woord['woord'].'####'.$cleanwoord.'--'.'<br/><br/><br/>';
            $numberindex++;
            
                    $updated = $this->updatewoord($woord['id'],$cleanwoord);
                    
            if($updated){
                $countupdated += 1;                
            }
        }
        echo '<br/><b>updated: --'.$countupdated.'--</b>';
    }
    public function updatewoord($id,$woord){
        return $this->query('update woords set woord = "'. $woord .'" where id='.$id);
    }
    public function cleanjustend($cleanwoord,$endstr){
        $r = true;
        $tempclean = $cleanwoord;
        while($r == true){
            $find = strpos($tempclean,$endstr);
            if($find === false){
                break;
            }
            if($find == (strlen($tempclean)-2)  ){
               $tempclean = substr($tempclean,0,-2);
               $cleanwoord = str_replace($tempclean.$endstr,$tempclean,$cleanwoord);
               $r = false;
            }
            else{
                $tempclean = substr($tempclean,$find+1);
            }
        }
        return $cleanwoord;
    }
}




?>