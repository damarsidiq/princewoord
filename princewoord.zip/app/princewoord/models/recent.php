<?php

Class Recent extends Model{
    function __construct(){
        parent::__construct('recent');
    }
    
    public function save($woord){
        $this->addrecord(array('woord'),array($woord));
    }
    
    public function thelist($data){
        $list = $this->getrecords(null,array('woord'),array('id','desc'),300);
        return $list;
    }
}

?>