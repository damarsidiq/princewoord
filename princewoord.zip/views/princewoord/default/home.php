<div id="bgcontainer">
    
</div>
<div id="container">
    <div id="header">
        <div id="thelogo" class="">Princewoord</div>
        <div id="recentsearch"></div>
        <div id="searchtool">
            <input type="button" value="Go" id="gosearch">
            <input type="text" name="Search" id="search" value="Search">
            <div class="woordnav">
                <span class="woordnav woordnavelem" id="previouswoord">&lt;</span>
                <span class="woordnav woordnavelem roundedright" id="nextwoord">&gt;</span>
            </div>
 
        </div>
    </div>
    
    <div id="contentcontainer">
        <div id="thecontent">
            <div id="pw_message" class="contentfetched"></div>
            <div id="pw_definition" class="contentfetched active"></div>
            <div id="pw_alsosee" class="contentfetched"></div>
            <div id="pw_similar" class="contentfetched"></div>
            <div id="pw_derived" class="contentfetched"></div>
            <div id="pw_holonym" class="contentfetched"></div>
            <div id="pw_meronym" class="contentfetched"></div>
            <div id="pw_attribute" class="contentfetched"></div>
            <div id="pw_hypernym" class="contentfetched"></div>
            <div id="pw_hyponym" class="contentfetched"></div>
            <div id="pw_similar" class="contentfetched"></div>
        </div>
        
        <div id="menus">
            <ul id="menulist">
                <li id="definition" class="active">Definition</li>
                <li id="alsosee">Also See</li>
                <li id="similar">Similar</li>
                <li id="attribute">Attribute</li>
                <li id="derived">Derivatives</li>
                <li id="meronym">Meronym</li>
                <li id="holonym">Holonym</li>
                <li id="hypernym">Hypernym</li>
                <li id="hyponym">Hyponym</li>
            </ul>
        </div>
    </div>
</div>