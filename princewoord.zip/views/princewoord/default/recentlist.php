<ol>

<?php foreach($pagevar['list'] as $k=>$v){ ?>
    
    <li class="recentitem"><?php echo $v['woord']; ?></li>

<?php } ?>

</ol>